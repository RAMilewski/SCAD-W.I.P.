These were to values observed in the example file.
Note mid thread has different pitch and chamfer length, is this correct? 

Thread Profiles
Big Thread
Major           22
Minor           21
Crest Weight    0.2
Root Weight     0.
Pitch           2.5
Chamfer         45
Chamfer Length  0.5


Mid Thread
Major           14
Minor           13
Crest Weight    0.2
Root Weight     0.2
Pitch           3
Chamfer Length  0.75


Small Thread
Major           7
Minor           6
Crest Weight    0.2
Root Weight     0.2
Pitch           3
Chamfer         45
Chamfer Length  0.5


