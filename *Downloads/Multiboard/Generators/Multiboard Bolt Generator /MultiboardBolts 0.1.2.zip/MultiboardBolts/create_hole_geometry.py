""" Create geometry to bool against bolt to create holes """
